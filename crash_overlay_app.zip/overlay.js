// overlay.js - small floating Crash helper
(function(){
  // State & default settings
  var SETTINGS_KEY = 'crash_helper_settings_v1';
  var DEFAULT = { name: 'المستخدم', cashout: 1.5, threshold: 0.55, interval: 3000 };
  var settings = Object.assign({}, DEFAULT, loadSettings());

  // Elements
  var widget = document.getElementById('widget');
  var last10Div = document.getElementById('last10');
  var recommendDiv = document.getElementById('recommend');
  var nameDiv = document.getElementById('name');
  var intervalLabel = document.getElementById('intervalLabel');

  var toggleSettingsBtn = document.getElementById('toggleSettings');
  var settingsPanel = document.getElementById('settings');
  var userNameInput = document.getElementById('userName');
  var cashoutInput = document.getElementById('cashout');
  var thresholdInput = document.getElementById('threshold');
  var saveSettingsBtn = document.getElementById('saveSettings');
  var refreshBtn = document.getElementById('refreshBtn');
  var closeBtn = document.getElementById('closeBtn');
  var openFull = document.getElementById('openFull');
  var downloadCsv = document.getElementById('downloadCsv');

  nameDiv.textContent = settings.name;
  userNameInput.value = settings.name;
  cashoutInput.value = settings.cashout;
  thresholdInput.value = settings.threshold;
  intervalLabel.textContent = Math.round(settings.interval/1000);

  // simple simulated data store: keep last results in localStorage (for demo)
  var DATA_KEY = 'crash_helper_history_v1';
  var history = loadHistory() || [];

  // initialize with some random history if empty
  if(!history || history.length===0){
    for(var i=0;i<10;i++){
      var m = sample_pareto(2.5,1.0);
      history.unshift({round: i+1, multiplier: +(m.toFixed(2))});
    }
    saveHistory();
  }

  // helper samplers (same as earlier)
  function rand(){ return Math.random(); }
  function sample_exp(lam){ var u=rand(); var m=1.0 - Math.log(u)/lam; return Math.max(1.0,m); }
  function sample_pareto(alpha,xm){ var u=rand(); var x = xm * Math.pow(u, -1.0/alpha); return Math.max(1.0,x); }

  // UI update
  function renderLast10(){
    last10Div.innerHTML = '';
    var last10 = history.slice(-10);
    last10.reverse();
    last10.forEach(function(h){
      var chip = document.createElement('div');
      chip.className = 'chip';
      chip.textContent = '×' + (h.multiplier.toFixed? h.multiplier.toFixed(2) : Number(h.multiplier).toFixed(2));
      last10Div.appendChild(chip);
    });
  }

  function computeRecommendation(){
    var last10 = history.slice(-10);
    if(last10.length===0){ recommendDiv.textContent = 'لا بيانات كافية'; return; }
    var cashout = parseFloat(settings.cashout) || 1.5;
    var succ = last10.filter(function(h){ return h.multiplier >= cashout; }).length;
    var prob = succ / last10.length;
    var text = 'احتمال نجاح عند ×' + cashout.toFixed(2) + ': ' + (prob*100).toFixed(0) + '%';
    var rec = (prob >= settings.threshold) ? 'توصية: ادخل' : 'توصية: لا تدخل';
    recommendDiv.textContent = text + ' · ' + rec;
  }

  function periodicUpdate(){
    // In a real helper you'd capture real game rounds; here we simulate new multiplier every interval
    // For user's purpose, they can manually enter real rounds later; but we auto-simulate to give live-like updates.
    var m = sample_pareto(2.5,1.0);
    history.push({ round: (history.length+1), multiplier: +(m.toFixed(2)) });
    // keep last 500
    if(history.length>500) history = history.slice(-500);
    saveHistory();
    renderLast10();
    computeRecommendation();
  }

  // save/load
  function saveSettings(){ localStorage.setItem(SETTINGS_KEY, JSON.stringify(settings)); }
  function loadSettings(){ try{ var s=localStorage.getItem(SETTINGS_KEY); return s? JSON.parse(s): {}; }catch(e){return{}} }
  function saveHistory(){ localStorage.setItem(DATA_KEY, JSON.stringify(history)); }
  function loadHistory(){ try{ var s=localStorage.getItem(DATA_KEY); return s? JSON.parse(s): []; }catch(e){return[];} }

  // initial render
  renderLast10();
  computeRecommendation();

  // start auto updates
  var timer = setInterval(periodicUpdate, settings.interval);

  // controls
  toggleSettingsBtn.addEventListener('click', function(){
    settingsPanel.style.display = settingsPanel.style.display === 'block' ? 'none' : 'block';
  });
  saveSettingsBtn.addEventListener('click', function(){
    settings.name = userNameInput.value || 'المستخدم';
    settings.cashout = parseFloat(cashoutInput.value) || 1.5;
    settings.threshold = parseFloat(thresholdInput.value) || 0.55;
    nameDiv.textContent = settings.name;
    saveSettings();
    clearInterval(timer);
    timer = setInterval(periodicUpdate, settings.interval);
    settingsPanel.style.display = 'none';
  });
  closeBtn.addEventListener('click', function(){ settingsPanel.style.display='none'; });

  refreshBtn.addEventListener('click', function(){ periodicUpdate(); });

  openFull.addEventListener('click', function(){
    var w = window.open('full.html', '_blank');
    if(!w) alert('فتح النافذة فشل. اسمح بالنوافذ المنبثقة أو افتح رابط full.html يدوياً.');
  });

  downloadCsv.addEventListener('click', function(){
    if(!history || history.length===0){ alert('لا يوجد بيانات'); return; }
    var csv = 'round,multiplier\n';
    history.forEach(function(r){ csv += r.round + ',' + r.multiplier + '\n'; });
    var blob = new Blob([csv], {type:'text/csv;charset=utf-8;'});
    var url = URL.createObjectURL(blob);
    var a = document.createElement('a'); a.href = url; a.download = 'crash_history.csv'; document.body.appendChild(a); a.click(); a.remove();
    URL.revokeObjectURL(url);
  });

  // draggable
  (function makeDraggable(el, handle){
    var pos = {x:0,y:0,dx:0,dy:0}, dragging=false;
    handle = handle || el;
    handle.addEventListener('pointerdown', function(e){
      dragging=true; pos.x = e.clientX; pos.y = e.clientY;
      el.setPointerCapture && el.setPointerCapture(e.pointerId);
    });
    window.addEventListener('pointermove', function(e){
      if(!dragging) return;
      var dx = e.clientX - pos.x; var dy = e.clientY - pos.y;
      pos.x = e.clientX; pos.y = e.clientY;
      var rect = el.getBoundingClientRect();
      el.style.right = 'auto';
      el.style.bottom = 'auto';
      el.style.left = Math.max(8, rect.left + dx) + 'px';
      el.style.top = Math.max(8, rect.top + dy) + 'px';
    });
    window.addEventListener('pointerup', function(e){
      dragging=false;
    });
  })(widget, document.getElementById('dragHandle'));

  // expose for debugging
  window.__crash_helper = { history: history, settings: settings, periodicUpdate: periodicUpdate };

})();
